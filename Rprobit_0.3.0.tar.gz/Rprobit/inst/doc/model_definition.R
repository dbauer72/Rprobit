## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")
options("Rprobit_progress" = FALSE)

## ---- eval = FALSE------------------------------------------------------------
#  formula <- choice ~ V1 | V2 | V3

## ---- eval = FALSE------------------------------------------------------------
#  formula <- choice ~  PS + Main | HI + HS + loc + CF +0  | range

## ---- eval = FALSE------------------------------------------------------------
#  re <- c("V1","V3")

## ---- eval = TRUE-------------------------------------------------------------
mod <- mod_cl$new(
  Hb   = diag(6),
  fb   = as.matrix(c(0,0,0,0,0,0),ncol=1),
  HO   = matrix(0,0,0),
  fO   = matrix(0,0,0),
  HL   = diag(6)[,-c(1,2,3,4)],
  fL   = as.matrix(c(0,0,0,1,0,0)),
  ordered = FALSE
)
mod

## ---- eval = TRUE-------------------------------------------------------------
check_identifiability(mod)

## ---- eval = TRUE-------------------------------------------------------------
mod <- mod_cl$new(
  Hb   = diag(6),
  fb   = as.matrix(c(0,0,0,0,0,0),ncol=1),
  HO   = matrix(0,0,0),
  fO   = matrix(0,0,0),
  HL   = diag(6)[,-c(1,2,3)],
  fL   = as.matrix(c(0,0,0,0,0,0)),
  ordered = FALSE
)
mod
check_identifiability(mod)

