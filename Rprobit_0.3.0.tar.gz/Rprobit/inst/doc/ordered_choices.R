## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")

## ---- echo = FALSE, label="data_gen"------------------------------------------
form <-  choice ~ 0 | V1 + V2 | 0
mod <- mod_cl$new(
  Hb   = diag(2)[,-1,drop=FALSE],
  fb   = as.matrix(c(1,0),ncol=1),
  HO   = matrix(0,0,0),
  fO   = matrix(0,0,0),
  HL   = matrix(1,1,1),
  fL   = as.matrix(c(1,0,1),ncol=1),
  alt  = 5,
  ordered = TRUE
)

Tp <- 3
HL <- diag(Tp*(Tp+1)/2)
HL <- as.matrix(apply(HL[,c(1,4,6),drop=FALSE],1,sum))
mod$HL <- HL
mod$fL <- matrix(0,6,1)
mod$alt <- 7
control_simul <- list(Tp = rep(3,1000))
re <- c()
  
set.seed(1)
theta_0 <- c(
  stats::rnorm(mod$lthb+mod$lthO),
  stats::runif(mod$lthL,1,2),-2, 
  stats::runif(mod$alt-2,-1,1)
)

Rprobit_obj <- setup_Rprobit(
  form = form, mod = mod, re = re, seed = 1, theta_0 = theta_0,
  control = control_simul
)
  
Rprobit_obj <- fit_Rprobit(Rprobit_obj = Rprobit_obj, init_method = "theta")

summary(Rprobit_obj)

## ---- echo = TRUE, label="data"-----------------------------------------------
Rprobit_obj$data_raw
Rprobit_obj$data_raw$df[1:9,]

Rprobit_obj$data
Rprobit_obj$data$data[[1]]


## ---- echo = TRUE, label = "est"----------------------------------------------
Rprobit_obj <- fit_Rprobit(Rprobit_obj = Rprobit_obj)
summary(Rprobit_obj)

