# test the estimation of state space system for ordered probit models

    Code
      round(Rp$theta, 2)
    Output
      [1]  0.94  0.00  1.00 -0.07  0.23  1.08  0.58  1.04  1.07

