# test #1: state space, CML, zero initial distribution

    Code
      round(Rp$theta, 2)
    Output
      [1]  1.00  0.22 -0.05  0.32  0.65 -0.11

# test #2: state space, CML, stationary initialisation

    Code
      round(Rp$theta, 2)
    Output
      [1]  0.97  0.01 -0.04  0.28  0.53  0.16

