# test #1: latent class, CML

    Code
      round(Rp$theta, 2)
    Output
      [1] 0.86 0.90

---

    Code
      round(Rp2$theta, 2)
    Output
      [1]  2.95 -0.01  3.30  3.11  0.11  3.02  0.02  0.18

# test #2: latent class, EM

    Code
      round(Rp$theta, 2)
    Output
      [1] 0.77 0.92

---

    Code
      round(Rp2$theta, 2)
    Output
                                              2     3 
       0.15  3.17  3.14  2.97  3.18 -0.12 -0.36 -0.54 

