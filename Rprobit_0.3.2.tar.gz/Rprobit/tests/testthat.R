library(testthat)
library(Rprobit)

Sys.setenv("R_TESTS" = "")
test_check("Rprobit")
