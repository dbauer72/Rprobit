#' @useDynLib Rprobit, .registration=TRUE
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp evalCpp
## usethis namespace: end
NULL
