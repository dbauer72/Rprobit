## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")

## ----echo = FALSE-------------------------------------------------------------
form <- choice ~ V1 + V2 | 0
re <- c()
mod <- mod_latclass_cl$new(
  Hb   = diag(2),
  fb   = as.matrix(c(0,0),ncol=1),
  HO   = matrix(0,0,0),
  fO   = matrix(0,0,0),
  HL   = matrix(0,6,0),
  fL   = matrix(0,6,1),
  ordered = FALSE,
)
mod$fL[c(1,4,6),1]=1
mod$num_class <- 3

theta_0 = c(2,0,0,2,2,2,0,0)

## ----echo = TRUE--------------------------------------------------------------
control_simul = list(Tp = rep(5,500))

# simulate data 
Rprobit_obj <- setup_Rprobit(
  form = form,
  mod = mod,
  re = re,
  seed = 1,
  theta_0 = theta_0,
  control = control_simul
)

Rprobit_obj$control$probit <- FALSE
Rprobit_obj$control$control_weights$cml_pair_type <- 0 # full pairwise CML function to be used.

## ----echo = TRUE--------------------------------------------------------------
modc <- mod_cl$new(
  Hb   = diag(2),
  fb   = as.matrix(c(0,0),ncol=1),
  HO   = matrix(0,0,0),
  fO   = matrix(0,0,0),
  HL   = matrix(0,6,0),
  fL   = matrix(0,6,1),
  ordered = FALSE,
)
modc$fL[c(1,4,6),1]=1

# evaluate at true parameter vector 
Rprobit_obj$mod <- modc

Rp <- fit_Rprobit(Rprobit_obj, init_method = "random")
summary(Rp) 

## ----echo = FALSE-------------------------------------------------------------
Rprobit_obj$control$el = 1
Rprobit_obj$mod <- mod
Rp2 <- fit_LC_Rprobit(Rprobit_obj,init_method = "random")
summary(Rp2)

## ----echo = FALSE-------------------------------------------------------------
Rprobit_obj$control$el = 1
Rprobit_obj$mod <- mod
Rp3 <- fit_LC_EM_Rprobit(Rprobit_obj,init_method = "random")
summary(Rp3)

## ----echo = FALSE-------------------------------------------------------------
modc <- mod_latclass_cl$new(
  Hb   = diag(2),
  fb   = as.matrix(c(0,0),ncol=1),
  HO   = matrix(0,1,0),
  fO   = matrix(0.25,1,1),
  HL   = matrix(0,6,0),
  fL   = matrix(0,6,1),
  ordered = FALSE,
)
modc$fL[c(1,4,6),1]=1
modc$num_class <- 3

# add first variable to list of random effects. 
Rprobit_obj$re <- c("V1")

# evaluate at true parameter vector 
Rprobit_obj$mod <- modc

Rp4 <- fit_LC_Rprobit(Rprobit_obj, init_method = "random")
summary(Rp4)

## ----echo = FALSE-------------------------------------------------------------
plot(Rp,dims = c(1,2))

## ----echo = FALSE-------------------------------------------------------------
plot(Rp2,dims = c(1,2))
plot(Rp3,dims = c(1,2))

## ----echo = FALSE-------------------------------------------------------------
plot(Rp4,dims = c(1))

## ----echo = FALSE-------------------------------------------------------------
plot(Rp4,dims = c(1),cdf=TRUE)

## ----echo = FALSE-------------------------------------------------------------
plot(Rp4,dims = c(1), cdf= TRUE,margin = 0.5)

## ----echo = FALSE-------------------------------------------------------------
plot(Rp4,dims = c(1,2))
plot(Rp4,dims = c(1,2), cdf= TRUE)

