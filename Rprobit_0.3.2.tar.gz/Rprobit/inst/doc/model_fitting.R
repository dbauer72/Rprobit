## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(Rprobit)

## ----fit_Rprobit--------------------------------------------------------------
require(mlogit)
data("Train", package = "mlogit")
Train$choiceid <- 1:nrow(Train)
Train$price_A <- Train$price_A / 100 * 2.20371
Train$price_B <- Train$price_B / 100 * 2.20371
Train$time_A <- Train$time_A / 60
Train$time_B <- Train$time_B / 60

# estimate a MNL model using mlogit
Train.ml <- mlogit.data(Train, choice = "choice", shape = "wide",
                     varying = 4:11, alt.levels = c("A", "B"), sep = "_",
                     opposite = c("price", "time", "change", "comfort"))

Train.mod <- mlogit(choice ~ price + time + change + comfort | 0, Train.ml, reflevel = "A", R=500)

# set up the probit model
train_mod <- setup_Rprobit(form = choice ~ price + time + change + comfort | 0 ,  data_raw = Train,  ids = c("id"))

# change scale fixation to price parameter. 
#train_mod$mod$lthL = 1
train_mod$mod$HL = matrix(0,3,1)
train_mod$mod$HL[3,1] = 1
train_mod$mod$fL = matrix(0,3,1)

#train_mod$mod$lthb = 3
train_mod$mod$Hb = diag(4)[,-1]
train_mod$mod$fb = as.matrix(c(-0.06,0,0,0),ncol=1)

# initialise with MNL results
train_mod$theta <- -c(as.numeric(Train.mod$coefficients[2:4]),1)
train_mod$theta_0 <- train_mod$theta


train_fit       <- fit_Rprobit(Rprobit_obj = train_mod,init_method = "random", 
                               control_nlm = list(approx_method = "SJ",probit = FALSE,hess = 0), cml_pair_type = 1)
summary(train_fit)

