## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")

## ----overview-Train-data------------------------------------------------------
data("Train", package = "mlogit")
str(Train)

## ----setup--------------------------------------------------------------------
require(mlogit)
data("Train", package = "mlogit")
Train$choiceid <- 1:nrow(Train)
train_mod <- setup_Rprobit(form = choice ~ price + time + change + comfort | 0 ,  data_raw = Train,  ids = c("id"))

## ----setup-simul--------------------------------------------------------------
form <- choice ~ V1 + V2 + V3 | 0 
re <- c("V1","V2")

### Define mod-object 
mod <- mod_cl$new(
  Hb   = diag(3)[,-3],
  fb   = as.matrix(c(0,0,1),col=1),
  HO   = diag(3),
  fO   = matrix(0,3,1),
  HL   = diag(6)[,-c(1,2,3)],
  fL   = matrix(0,6,1),
  ordered = FALSE
)
control_simul <- list(Tp = sample(1:3,1000,replace=TRUE))
Rprobit_obj <- setup_Rprobit(form = form, mod = mod, re = re, seed = 1, control = control_simul)

