## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")

## ----eval = FALSE-------------------------------------------------------------
#  formula <- choice ~ V1 | V2 | V3

## ----eval = FALSE-------------------------------------------------------------
#  formula <- choice ~  PS + Main | HI + HS + loc + CF + 0 | range

## ----eval = FALSE-------------------------------------------------------------
#  re <- c("V1", "V3")

## ----eval = TRUE--------------------------------------------------------------
mod <- mod_cl$new(
  Hb = diag(6),
  fb = matrix(0, ncol = 1, nrow = 6),
  HO = matrix(0, ncol = 0, nrow = 0),
  fO = matrix(0, ncol = 0, nrow = 0),
  HL = diag(6)[, -c(1, 2, 3, 4)],
  fL = matrix(c(0, 0, 0, 1, 0, 0), ncol = 1),
)

## ----eval = TRUE--------------------------------------------------------------
print(mod)

## ----eval = TRUE--------------------------------------------------------------
check_identifiability(mod)

## ----eval = TRUE, warning = TRUE----------------------------------------------
mod$HL <- diag(6)[, -c(1, 2, 3)]
mod$fL <- matrix(0, ncol = 1, nrow = 6)
check_identifiability(mod)

