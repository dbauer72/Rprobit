## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.path = "img/",
  fig.align = "center",
  fig.dim = c(8, 6), 
  out.width = "75%"
)
library("Rprobit")

## ----echo = FALSE-------------------------------------------------------------
library("AER")
library("mlogit")
data("TravelMode", package ="AER")
TM <- mlogit.data(TravelMode,choice = "choice", shape = "long", alt.levels = c("air","train","bus","car"))

TM$avinc <- with(TM,(mode=="air")*income)
# estimating a nested logit model 
nl.TM <- mlogit(choice ~ wait+ avinc  + I(gcost-vcost) + travel | size | 0 , TM, reflevel = "car", nests = list(fly = "air", ground = c("train", "bus","car")), unscaled =TRUE)
summary(nl.TM)

pr = predict(nl.TM,newdata=TM)

# calculate predictions for all alternatives 
# and confusion matrix.
conf_mat <- function(choice,pr){
  N = dim(pr)[1]
  J = dim(pr)[2]
  
  pred_choice = matrix(0,N,1)
  conf_mat = matrix(0,J,J)
  
  for (j in 1:N){
    pred_choice[j] =  which.max(pr[j,]) 
    conf_mat[choice[j],pred_choice[j]] = conf_mat[choice[j],pred_choice[j]]  +1
  }
  alt_names <- colnames(pr)
  colnames(conf_mat) <- alt_names
  rownames(conf_mat) <- alt_names
  return (list(pred_choice=pred_choice,conf_mat = conf_mat))
} 

pr = predict(nl.TM,newdata=TM)
choice = pr[,1]*0
fml = fitted(nl.TM)

for (j in 1:210){
  choice[j] = which.min(abs(pr[j,]-fml[j])) 
}


cm = conf_mat(choice,pr)
cm$conf_mat


## ----echo = FALSE-------------------------------------------------------------
head(TravelMode)

# add avinc column 
TravelMode["avinc"] <- with(TravelMode,(mode=="air")*income)

data_raw = convert_data_long_data_raw(df= TravelMode,id_dec="individual", id_choice="individual",alternative="mode",choice="choice")

data_raw

## ----echo = FALSE-------------------------------------------------------------
form <- choice ~ wait+ avinc + gcost + vcost + travel | size | 0 
Travel_Rprobit <- setup_Rprobit(form, data_raw=data_raw, norm_alt="car",re=c(), error_struc="full")
Travel_Rprobit$data = NULL
Travel_Rprobit$theta_0 = c(-0.06,0.02,0.03,-.04,-0.007,-0.5,-0.3,-0.025,3,2.7,2.7,0,0,1,0,1) 
Travel_Rprobit$theta = Travel_Rprobit$theta_0
Travel_Rprobit <- fit_Rprobit(Rprobit_obj = Travel_Rprobit,init_method = "theta", cml_pair_type=0)
summary(Travel_Rprobit)

out <- confmat_Rprobit(Travel_Rprobit)
out$conf_mat
sum(diag(out$conf_mat))/sum(out$conf_mat)

## ----echo = FALSE-------------------------------------------------------------
form <- choice ~ wait+ avinc + gcost + vcost + travel | size | 0 
Travel_Rprobit <- setup_Rprobit(form, data_raw=data_raw, norm_alt="car",re=c(), error_struc="full")

Hb <- Travel_Rprobit$mod$Hb
Hb[,3] = Hb[,3]-Hb[,4]
Hb = Hb[,-4]
Travel_Rprobit$mod$Hb = Hb


Travel_Rprobit$theta_0 = c(-0.05,0.013,0.04,-0.006,-0.53,-0.25,-0.16,3.6,3,2.9,1.3,0.88,-1,0.4,0.7)
Travel_Rprobit <- fit_Rprobit(Rprobit_obj = Travel_Rprobit,init_method = "theta")
summary(Travel_Rprobit)

Travel_Rprobit$data_raw$alt_names = c("air","bus","car","train") 
out <- confmat_Rprobit(Travel_Rprobit)
out$conf_mat
sum(diag(out$conf_mat))/sum(out$conf_mat)

## ----echo = FALSE-------------------------------------------------------------
form <- choice ~ avinc + gcost + vcost  + travel | size | wait 
Travel_Rprobit <- setup_Rprobit(form, data_raw=data_raw, norm_alt="car",re=c(), error_struc="full")
# wait is zero for the car -> need to take out coefficient. 
Travel_Rprobit$mod$Hb = Travel_Rprobit$mod$Hb[,-10]

Travel_Rprobit$theta = c(0.017,0.011,-0.012,-0.0018,-0.22,-0.015,-0.010,-0.04,-0.002,-0.0,.2,0.13,0.07,.99,0.97,0.05,0.02,0.01)
Travel_Rprobit <- fit_Rprobit(Rprobit_obj = Travel_Rprobit,init_method = "theta")
summary(Travel_Rprobit)

Travel_Rprobit$data_raw$alt_names = c("air","bus","car","train")                
out <- confmat_Rprobit(Travel_Rprobit)
out$conf_mat
sum(diag(out$conf_mat))/sum(out$conf_mat)

cm$conf_mat
sum(diag(cm$conf_mat))/sum(cm$conf_mat)


